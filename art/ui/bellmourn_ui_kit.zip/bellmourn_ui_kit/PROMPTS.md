# The sheets, one by one

20 sheets. Do the **A** sheets first (they change the look of the whole game by themselves), then **B**, then **C**.
Any that come back are used; the game draws the rest itself as it does now.

| Sheet | Priority | Size | What |
| --- | --- | --- | --- |
| `buttons` | A | 1024 x 1024 | The round buttons |
| `icons_actions` | A | 1024 x 1024 | Icons: what the thumbs do |
| `icons_menus` | A | 1024 x 1024 | Icons: the menus |
| `panel` | A | 1024 x 1024 | The window frame |
| `spells_fire` | B | 1536 x 1024 | Spells: Fire |
| `spells_ice` | B | 1536 x 1024 | Spells: Ice |
| `spells_earth` | B | 1536 x 1024 | Spells: Earth |
| `spells_arcane` | B | 1536 x 1024 | Spells: Arcane |
| `spells_lightning` | B | 1536 x 1024 | Spells: Lightning |
| `spells_utility` | B | 1536 x 1024 | Spells: Utility |
| `sockets` | B | 1024 x 1024 | Sockets and the medal |
| `rings` | B | 1024 x 1024 | The map's frame and the stick |
| `plates` | B | 1536 x 1024 | Buttons, tabs and the rule |
| `bars` | B | 1536 x 1024 | The bars |
| `paper` | C | 1024 x 1024 | Parchment |
| `icons_slots` | C | 1024 x 1024 | Icons: empty gear slots, and two marks |
| `icons_goods` | C | 1024 x 1024 | Icons: goods, materials and charms |
| `gems` | C | 1536 x 1024 | Icons: the gems |
| `icons_marks` | C | 1536 x 1024 | Icons: quest marks and party roles |
| `app_icon` | C | 1024 x 1024 | The app's icon |

Every prompt below starts with the same style lock (`STYLE.md`). Don't shorten it or reword it between sheets: it is what
makes 20 pictures look like one set.

## buttons: The round buttons

- **Save as:** `art/buttons.png`   **Size:** 1024 x 1024   **Priority:** A
- **Template:** `templates/buttons_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: The round buttons.
The bases of the buttons a thumb presses on a phone: a round boss, seen straight on, perfectly circular, filling its cell to the guide circle. The game draws an icon in the middle, so the middle is an empty, dark, slightly domed field. No icon, no gem in the centre.

LAYOUT: Canvas 1024 x 1024 pixels. An invisible grid of 2 columns by 2 rows of equal cells (512 x 512 each), read left to right, top to bottom. One picture in each cell. Each piece fills its cell almost to the edges (to the dashed guide in the template), perfectly centred. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. The ordinary button, at rest: a blackened iron disc with a bronze-gold rim worked in fine filigree, four tiny garnet studs at the compass points of the rim, the centre a dark, slightly domed field.
2. The same button, pressed or switched on: identical shape and rim, the rim brighter gold and the centre lit with a warm inner glow, the garnets alight.
3. The big main-attack button, at rest: the same make but grander, a heavier double rim with eight garnet studs and small pointed finials at the four compass points (kept inside the guide circle), the centre a dark domed field.
4. The same big button, pressed: identical shape, rim blazing gold, centre lit from within.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `btn_round` | The ordinary button, at rest: a blackened iron disc with a bronze-gold rim worked in fine filigree, four tiny garnet studs at the compass points of the rim, the centre a dark, slightly domed field. |
| 2 | `btn_round_on` | The same button, pressed or switched on: identical shape and rim, the rim brighter gold and the centre lit with a warm inner glow, the garnets alight. |
| 3 | `btn_main` | The big main-attack button, at rest: the same make but grander, a heavier double rim with eight garnet studs and small pointed finials at the four compass points (kept inside the guide circle), the centre a dark domed field. |
| 4 | `btn_main_on` | The same big button, pressed: identical shape, rim blazing gold, centre lit from within. |

## icons_actions: Icons: what the thumbs do

- **Save as:** `art/icons_actions.png`   **Size:** 1024 x 1024   **Priority:** A
- **Template:** `templates/icons_actions_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Icons: what the thumbs do.
Sixteen icons that sit on the round buttons. Pale bone-and-gold objects that read at a glance on a dark button at the size of a fingernail: one object each, bold silhouette, no frame, no background.

LAYOUT: Canvas 1024 x 1024 pixels. An invisible grid of 4 columns by 4 rows of equal cells (256 x 256 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. A wizard's staff held at a slant, its head a glowing orb throwing off three small sparks. The main attack.
2. A kite shield, front on, plain steel face with a raised rim and a single boss. No device on it.
3. A pair of worn leather boots leaving the ground, a small puff of dust under them, an upward sweep above.
4. A cloaked figure in a low sideways lunge with speed streaks trailing behind. A quick sidestep.
5. A single leather boot in mid stride, leaning forward, three speed streaks trailing behind it. Running.
6. An open hand, palm up, with a four-pointed star of light bursting above it. Cast a spell.
7. A gloved hand reaching down to grasp, fingers spread. Pick something up.
8. Two overlapping speech scrolls (curled parchment ribbons), blank. Talk to someone.
9. A heavy wooden door with iron bands, standing ajar, warm light spilling through the gap.
10. The same heavy wooden door with iron bands, closed, a ring handle on it.
11. An old iron padlock, closed, with a keyhole. A locked door.
12. A traveller's leather backpack with a buckled flap and a bedroll strapped on top. The inventory.
13. A thick closed spellbook with metal corners and a clasp, a four-pointed star gem set in its cover.
14. A rolled parchment scroll partly unrolled, with a quill pen lying across it. The quest journal.
15. A folded parchment map with a dotted path ending at a small red diamond, one corner curling.
16. Three short horizontal iron bars stacked, each with a small rivet at both ends. The menu.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `staff` | A wizard's staff held at a slant, its head a glowing orb throwing off three small sparks. The main attack. |
| 2 | `guard` | A kite shield, front on, plain steel face with a raised rim and a single boss. No device on it. |
| 3 | `jump` | A pair of worn leather boots leaving the ground, a small puff of dust under them, an upward sweep above. |
| 4 | `dodge` | A cloaked figure in a low sideways lunge with speed streaks trailing behind. A quick sidestep. |
| 5 | `sprint` | A single leather boot in mid stride, leaning forward, three speed streaks trailing behind it. Running. |
| 6 | `cast` | An open hand, palm up, with a four-pointed star of light bursting above it. Cast a spell. |
| 7 | `take` | A gloved hand reaching down to grasp, fingers spread. Pick something up. |
| 8 | `talk` | Two overlapping speech scrolls (curled parchment ribbons), blank. Talk to someone. |
| 9 | `open` | A heavy wooden door with iron bands, standing ajar, warm light spilling through the gap. |
| 10 | `shut` | The same heavy wooden door with iron bands, closed, a ring handle on it. |
| 11 | `locked` | An old iron padlock, closed, with a keyhole. A locked door. |
| 12 | `pack` | A traveller's leather backpack with a buckled flap and a bedroll strapped on top. The inventory. |
| 13 | `book` | A thick closed spellbook with metal corners and a clasp, a four-pointed star gem set in its cover. |
| 14 | `journal` | A rolled parchment scroll partly unrolled, with a quill pen lying across it. The quest journal. |
| 15 | `map` | A folded parchment map with a dotted path ending at a small red diamond, one corner curling. |
| 16 | `menu` | Three short horizontal iron bars stacked, each with a small rivet at both ends. The menu. |

## icons_menus: Icons: the menus

- **Save as:** `art/icons_menus.png`   **Size:** 1024 x 1024   **Priority:** A
- **Template:** `templates/icons_menus_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Icons: the menus.
Sixteen more icons of the same family as the first sheet, for the top bar and the menus. Same make, same weight, same palette.

LAYOUT: Canvas 1024 x 1024 pixels. An invisible grid of 4 columns by 4 rows of equal cells (256 x 256 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. A single open eye, heavy lidded, iris catching light. First-person view.
2. A small robed wizard figure seen from behind and above, pointed hat, staff in hand. Third-person view.
3. Two short iron bars crossed on the diagonal, riveted where they meet (the one place in the set a crossed shape is wanted). Close.
4. Three small stacked chests, biggest at the bottom, smallest on top. Sort the pack.
5. A brass magnifying lens with a wooden handle, a bright four-pointed glint in its glass. Look closer.
6. The same brass magnifying lens, held further off and smaller in its cell, its glass dark and plain. Look from further away.
7. A brass compass rose with a needle, four points. Centre the map on yourself.
8. A right-pointing arrowhead of polished gold. Resume.
9. A quill writing in an open book. Save the game.
10. An open book with a ribbon bookmark and a page turning back. Load a game.
11. Two interlocking iron cogwheels. Settings.
12. A lit candle beside an open book. How to play.
13. A small stone gatehouse with an arched doorway and a pointed roof. Main menu.
14. A small heap of plain gold coins, blank faces. Gold.
15. A gold four-pointed star with a small diamond at its centre. A quest marker.
16. A hand-held slate tablet shown twice: upright and faint, then lying on its side and solid, a curved arrow between them. Turn the screen sideways.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `view1` | A single open eye, heavy lidded, iris catching light. First-person view. |
| 2 | `view3` | A small robed wizard figure seen from behind and above, pointed hat, staff in hand. Third-person view. |
| 3 | `close` | Two short iron bars crossed on the diagonal, riveted where they meet (the one place in the set a crossed shape is wanted). Close. |
| 4 | `sort` | Three small stacked chests, biggest at the bottom, smallest on top. Sort the pack. |
| 5 | `plus` | A brass magnifying lens with a wooden handle, a bright four-pointed glint in its glass. Look closer. |
| 6 | `minus` | The same brass magnifying lens, held further off and smaller in its cell, its glass dark and plain. Look from further away. |
| 7 | `centre` | A brass compass rose with a needle, four points. Centre the map on yourself. |
| 8 | `resume` | A right-pointing arrowhead of polished gold. Resume. |
| 9 | `save` | A quill writing in an open book. Save the game. |
| 10 | `load` | An open book with a ribbon bookmark and a page turning back. Load a game. |
| 11 | `settings` | Two interlocking iron cogwheels. Settings. |
| 12 | `howto` | A lit candle beside an open book. How to play. |
| 13 | `home` | A small stone gatehouse with an arched doorway and a pointed roof. Main menu. |
| 14 | `gold` | A small heap of plain gold coins, blank faces. Gold. |
| 15 | `quest` | A gold four-pointed star with a small diamond at its centre. A quest marker. |
| 16 | `rotate` | A hand-held slate tablet shown twice: upright and faint, then lying on its side and solid, a curved arrow between them. Turn the screen sideways. |

## panel: The window frame

- **Save as:** `art/panel.png`   **Size:** 1024 x 1024   **Priority:** A
- **Template:** `templates/panel_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: The window frame.
The frame of every window in the game (the pack, the spellbook, a conversation, the settings). One square frame filling the sheet edge to edge, seen straight on: a border of blackened iron with a bronze-gold inner bead, ornate corners with a small garnet stud in each, and a plain dark centre (near-black warm brown, very faint leather grain, no picture). The game cuts it in nine and stretches it: the four corners are kept as they are, so every ornament must stay inside the corner squares the template marks; the four sides between the corners must be plain, straight and the same all along their length; the centre must be even.

LAYOUT: Canvas 1024 x 1024 pixels. One frame fills the whole canvas, right to its edges, seen straight on, with four-way symmetry. All ornament is inside the four corner squares (each 192 x 192 pixels); between the corners each side is a plain straight band that looks the same all along its length; the centre is plain and even.
```

## spells_fire: Spells: Fire

- **Save as:** `art/spells_fire.png`   **Size:** 1536 x 1024   **Priority:** B
- **Template:** `templates/spells_fire_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Spells: Fire.
The ten spells of the school of Fire, and its emblem. Every icon on this sheet is lit by and coloured with the school's own colour, #ff9a3c, on the dark neutral ground of the style lock: one glowing magical effect in each cell, no hands, no figures, no frame or border round it (the game puts each in a round socket).

LAYOUT: Canvas 1536 x 1024 pixels. An invisible grid of 4 columns by 3 rows of equal cells (384 x 341 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. Firebolt. Hold to gather it in the hand, up to two seconds, then it roars away and bursts where it lands. The longer it gathers, the harder it bursts.
2. Fire Beam. Hold: a roaring jet of flame pours from your palms, searing and setting alight whatever it plays across.
3. Cinderburst. A knot of cinders that bursts where it lands and scatters embers all round, each one a small fire of its own.
4. Wall of Fire. Raises a wall of fire nine paces long where you look, for eight seconds. What crosses it goes up in flames.
5. Ring of Fire. A ring of flame rolls out from where you stand, scorching all it passes, and stands there six seconds as a moat: what crosses it burns.
6. Flame Wyrm. A serpent of fire that weaves its own way to the nearest foe, and leaves the ground alight where it strikes.
7. Phoenix. A firebird flies through everything in its way, dies in a ring of flame among them, and its ashes mend you.
8. Cinder Brand. Brands a foe with a coal that burns down and bursts. If the foe dies to it, the brand leaps to the two nearest.
9. Inferno. For twelve seconds you are wreathed in fire: all within reach burn, and the ground burns where you have walked.
10. Meteor. Calls a burning stone out of the sky onto where you look, and leaves the ground on fire.
11. The emblem of the school of Fire: A single tall flame. Simple and bold, to sit on a tab.
12. Leave this cell empty.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `firebolt` | Firebolt. Hold to gather it in the hand, up to two seconds, then it roars away and bursts where it lands. The longer it gathers, the harder it bursts. |
| 2 | `firebeam` | Fire Beam. Hold: a roaring jet of flame pours from your palms, searing and setting alight whatever it plays across. |
| 3 | `comet` | Cinderburst. A knot of cinders that bursts where it lands and scatters embers all round, each one a small fire of its own. |
| 4 | `wallfire` | Wall of Fire. Raises a wall of fire nine paces long where you look, for eight seconds. What crosses it goes up in flames. |
| 5 | `firenova` | Ring of Fire. A ring of flame rolls out from where you stand, scorching all it passes, and stands there six seconds as a moat: what crosses it burns. |
| 6 | `wyrm` | Flame Wyrm. A serpent of fire that weaves its own way to the nearest foe, and leaves the ground alight where it strikes. |
| 7 | `phoenix` | Phoenix. A firebird flies through everything in its way, dies in a ring of flame among them, and its ashes mend you. |
| 8 | `bomb` | Cinder Brand. Brands a foe with a coal that burns down and bursts. If the foe dies to it, the brand leaps to the two nearest. |
| 9 | `inferno` | Inferno. For twelve seconds you are wreathed in fire: all within reach burn, and the ground burns where you have walked. |
| 10 | `meteor` | Meteor. Calls a burning stone out of the sky onto where you look, and leaves the ground on fire. |
| 11 | `school_fire` | The emblem of the school of Fire: A single tall flame. Simple and bold, to sit on a tab. |
| 12 | (empty) |  |

## spells_ice: Spells: Ice

- **Save as:** `art/spells_ice.png`   **Size:** 1536 x 1024   **Priority:** B
- **Template:** `templates/spells_ice_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Spells: Ice.
The ten spells of the school of Ice, and its emblem. Every icon on this sheet is lit by and coloured with the school's own colour, #8fd4ff, on the dark neutral ground of the style lock: one glowing magical effect in each cell, no hands, no figures, no frame or border round it (the game puts each in a round socket).

LAYOUT: Canvas 1536 x 1024 pixels. An invisible grid of 4 columns by 3 rows of equal cells (384 x 341 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. Frost Shards. Three splinters of ice that shatter into frost and slow what they strike.
2. Cone of Cold. A breath of winter from both hands: everything in a cone before you is cut by it and slowed.
3. Rime Lance. A lance of ice that freezes what it strikes for a moment and bursts into shards all round.
4. Frost Nova. Ice bursts out from where you stand: all within ten paces are frozen solid for five seconds, and take half again from every blow.
5. Ray of Frost. Hold: a ray of bitter cold that slows what it plays on, and freezes solid what it is held on long enough.
6. Prismatic Shard. A crystal that splits on what it strikes into three beams of cold light, running on through everything behind and slowing it.
7. Blizzard. Ice rains on the ground you mark for seven seconds, cutting and slowing all beneath.
8. Shatter. Every slowed foe within sixteen paces cracks. Every frozen one breaks out of its ice for twice as much, and the shards cut those beside it.
9. Frozen Orb. A slow globe of ice that rolls through the fight throwing shards in every direction, then bursts.
10. Deadwinter. Marks the ground you look at. A breath later all warmth leaves it: everything inside is frozen solid for six seconds.
11. The emblem of the school of Ice: A six-armed ice crystal. Simple and bold, to sit on a tab.
12. Leave this cell empty.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `frost` | Frost Shards. Three splinters of ice that shatter into frost and slow what they strike. |
| 2 | `coldcone` | Cone of Cold. A breath of winter from both hands: everything in a cone before you is cut by it and slowed. |
| 3 | `rime` | Rime Lance. A lance of ice that freezes what it strikes for a moment and bursts into shards all round. |
| 4 | `nova` | Frost Nova. Ice bursts out from where you stand: all within ten paces are frozen solid for five seconds, and take half again from every blow. |
| 5 | `frostray` | Ray of Frost. Hold: a ray of bitter cold that slows what it plays on, and freezes solid what it is held on long enough. |
| 6 | `prism` | Prismatic Shard. A crystal that splits on what it strikes into three beams of cold light, running on through everything behind and slowing it. |
| 7 | `blizzard` | Blizzard. Ice rains on the ground you mark for seven seconds, cutting and slowing all beneath. |
| 8 | `shatter` | Shatter. Every slowed foe within sixteen paces cracks. Every frozen one breaks out of its ice for twice as much, and the shards cut those beside it. |
| 9 | `orb` | Frozen Orb. A slow globe of ice that rolls through the fight throwing shards in every direction, then bursts. |
| 10 | `zero` | Deadwinter. Marks the ground you look at. A breath later all warmth leaves it: everything inside is frozen solid for six seconds. |
| 11 | `school_ice` | The emblem of the school of Ice: A six-armed ice crystal. Simple and bold, to sit on a tab. |
| 12 | (empty) |  |

## spells_earth: Spells: Earth

- **Save as:** `art/spells_earth.png`   **Size:** 1536 x 1024   **Priority:** B
- **Template:** `templates/spells_earth_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Spells: Earth.
The ten spells of the school of Earth, and its emblem. Every icon on this sheet is lit by and coloured with the school's own colour, #d8b184, on the dark neutral ground of the style lock: one glowing magical effect in each cell, no hands, no figures, no frame or border round it (the game puts each in a round socket).

LAYOUT: Canvas 1536 x 1024 pixels. An invisible grid of 4 columns by 3 rows of equal cells (384 x 341 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. Stone Shard. A fist of rock, thrown hard: it staggers what it strikes and knocks it back a step.
2. Bone Lance. A spear of sharpened bone that runs through every body in its line and sticks quivering in the wall.
3. Thorn Volley. A fan of five thorns. What they strike is left rotting for four seconds.
4. Earthsplitter. Spikes of stone burst from the ground in a line before you, impaling what stands there and flinging it into the air.
5. Rolling Boulder. A boulder that bounds on from where it lands, three times, bursting among whatever is there each time. It hurts no one twice.
6. Plague Flask. A lobbed flask that bursts in a choking green cloud: for nine seconds everything inside it rots and slows.
7. Stoneskin. Your skin turns to stone for twenty seconds: every blow that lands does a third less.
8. Grasping Vines. Where it lands, vines come up under the five nearest, tear at them and hold them fast where they stand.
9. Earthquake. The ground you mark heaves for six seconds: all on it are slowed, and every jolt, one each second and a half, batters them and throws them off their feet.
10. Monolith. A slab of stone bursts up under whatever you look at: one great blow that throws it into the air and leaves it stunned.
11. The emblem of the school of Earth: A rough standing stone with a crack. Simple and bold, to sit on a tab.
12. Leave this cell empty.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `stone` | Stone Shard. A fist of rock, thrown hard: it staggers what it strikes and knocks it back a step. |
| 2 | `lance` | Bone Lance. A spear of sharpened bone that runs through every body in its line and sticks quivering in the wall. |
| 3 | `thorns` | Thorn Volley. A fan of five thorns. What they strike is left rotting for four seconds. |
| 4 | `spikes` | Earthsplitter. Spikes of stone burst from the ground in a line before you, impaling what stands there and flinging it into the air. |
| 5 | `boulder` | Rolling Boulder. A boulder that bounds on from where it lands, three times, bursting among whatever is there each time. It hurts no one twice. |
| 6 | `plague` | Plague Flask. A lobbed flask that bursts in a choking green cloud: for nine seconds everything inside it rots and slows. |
| 7 | `stoneskin` | Stoneskin. Your skin turns to stone for twenty seconds: every blow that lands does a third less. |
| 8 | `vine` | Grasping Vines. Where it lands, vines come up under the five nearest, tear at them and hold them fast where they stand. |
| 9 | `quake` | Earthquake. The ground you mark heaves for six seconds: all on it are slowed, and every jolt, one each second and a half, batters them and throws them off their feet. |
| 10 | `monolith` | Monolith. A slab of stone bursts up under whatever you look at: one great blow that throws it into the air and leaves it stunned. |
| 11 | `school_earth` | The emblem of the school of Earth: A rough standing stone with a crack. Simple and bold, to sit on a tab. |
| 12 | (empty) |  |

## spells_arcane: Spells: Arcane

- **Save as:** `art/spells_arcane.png`   **Size:** 1536 x 1024   **Priority:** B
- **Template:** `templates/spells_arcane_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Spells: Arcane.
The ten spells of the school of Arcane, and its emblem. Every icon on this sheet is lit by and coloured with the school's own colour, #d27bff, on the dark neutral ground of the style lock: one glowing magical effect in each cell, no hands, no figures, no frame or border round it (the game puts each in a round socket).

LAYOUT: Canvas 1536 x 1024 pixels. An invisible grid of 4 columns by 3 rows of equal cells (384 x 341 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. Magic Missiles. Hold: spinning missiles fan out and hang in the air, more the longer you hold, and dart off one hard after another to seek a foe.
2. Arcane Blast. A clap of raw force from both hands: everything in a cone before you is torn at and hurled back.
3. Blink. Vanish and step out up to fourteen paces ahead, tearing through anything in the way.
4. Spirit Blades. Four ghostly swords wheel round you for twenty seconds, hacking at anything that comes near.
5. Rune of Force. Writes a rune on the ground where you look. The first foe to step on it is blown off its feet with everything near. Three may lie at once.
6. Moonblade. A spinning crescent that cuts its way out eighteen paces and comes back to your hand, cutting again.
7. Gravity Well. A mote of darkness that hangs where it lands, dragging all within ten paces into it, then bursts.
8. Stasis. A sphere where time stops. What is inside hangs there for three seconds, then pays for all of it at once.
9. Disintegrate. Hold: a lance of raw force through everything in its line, biting harder the longer it is held.
10. Starfall. Marks the ground you look at, and a moment later ten stars come down on it one after another.
11. The emblem of the school of Arcane: A crescent moon with one star. Simple and bold, to sit on a tab.
12. Leave this cell empty.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `missiles` | Magic Missiles. Hold: spinning missiles fan out and hang in the air, more the longer you hold, and dart off one hard after another to seek a foe. |
| 2 | `arcaneblast` | Arcane Blast. A clap of raw force from both hands: everything in a cone before you is torn at and hurled back. |
| 3 | `blink` | Blink. Vanish and step out up to fourteen paces ahead, tearing through anything in the way. |
| 4 | `blades` | Spirit Blades. Four ghostly swords wheel round you for twenty seconds, hacking at anything that comes near. |
| 5 | `rune` | Rune of Force. Writes a rune on the ground where you look. The first foe to step on it is blown off its feet with everything near. Three may lie at once. |
| 6 | `crescent` | Moonblade. A spinning crescent that cuts its way out eighteen paces and comes back to your hand, cutting again. |
| 7 | `well` | Gravity Well. A mote of darkness that hangs where it lands, dragging all within ten paces into it, then bursts. |
| 8 | `stasis` | Stasis. A sphere where time stops. What is inside hangs there for three seconds, then pays for all of it at once. |
| 9 | `disintegrate` | Disintegrate. Hold: a lance of raw force through everything in its line, biting harder the longer it is held. |
| 10 | `starfall` | Starfall. Marks the ground you look at, and a moment later ten stars come down on it one after another. |
| 11 | `school_arcane` | The emblem of the school of Arcane: A crescent moon with one star. Simple and bold, to sit on a tab. |
| 12 | (empty) |  |

## spells_lightning: Spells: Lightning

- **Save as:** `art/spells_lightning.png`   **Size:** 1536 x 1024   **Priority:** B
- **Template:** `templates/spells_lightning_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Spells: Lightning.
The ten spells of the school of Lightning, and its emblem. Every icon on this sheet is lit by and coloured with the school's own colour, #a79bff, on the dark neutral ground of the style lock: one glowing magical effect in each cell, no hands, no figures, no frame or border round it (the game puts each in a round socket).

LAYOUT: Canvas 1536 x 1024 pixels. An invisible grid of 4 columns by 3 rows of equal cells (384 x 341 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. Spark. A crack of lightning straight to what you look at. Nothing outruns it.
2. Chain Lightning. Hold: lightning streams from your palm, and from whatever it strikes it leaps to the nearest other, up to five times.
3. Forked Lightning. Lightning that splits as it leaves the hand: three forks, each to a foe of its own before you.
4. Storm Seed. A spark that sticks to what it strikes, or where it lands, for six seconds. Any lightning that strikes there leaps on to everyone within seven paces. Two may be set at once.
5. Ball Lightning. A slow sphere of storm that lashes everything around it, then detonates.
6. Thunderclap. A clap of thunder from where you stand: all within six paces are thrown back and left stunned.
7. Stormstep. You go as lightning to the foe you look at, through everything between, and arrive on it in a crack of thunder that leaves it stunned.
8. Thunderbolt. Calls a bolt out of the sky onto where you look. What it strikes is stunned, if it lives.
9. Static Field. For fifteen seconds lightning leaps from you to the three nearest foes within six paces, once a second.
10. Thunderstorm. A storm gathers over the ground you mark: for eight seconds bolt after bolt comes down on whoever is under it.
11. The emblem of the school of Lightning: A forked lightning bolt. Simple and bold, to sit on a tab.
12. Leave this cell empty.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `spark` | Spark. A crack of lightning straight to what you look at. Nothing outruns it. |
| 2 | `chain` | Chain Lightning. Hold: lightning streams from your palm, and from whatever it strikes it leaps to the nearest other, up to five times. |
| 3 | `fork` | Forked Lightning. Lightning that splits as it leaves the hand: three forks, each to a foe of its own before you. |
| 4 | `seed` | Storm Seed. A spark that sticks to what it strikes, or where it lands, for six seconds. Any lightning that strikes there leaps on to everyone within seven paces. Two may be set at once. |
| 5 | `lightning` | Ball Lightning. A slow sphere of storm that lashes everything around it, then detonates. |
| 6 | `thunderclap` | Thunderclap. A clap of thunder from where you stand: all within six paces are thrown back and left stunned. |
| 7 | `stormstep` | Stormstep. You go as lightning to the foe you look at, through everything between, and arrive on it in a crack of thunder that leaves it stunned. |
| 8 | `thunder` | Thunderbolt. Calls a bolt out of the sky onto where you look. What it strikes is stunned, if it lives. |
| 9 | `staticfield` | Static Field. For fifteen seconds lightning leaps from you to the three nearest foes within six paces, once a second. |
| 10 | `tempest` | Thunderstorm. A storm gathers over the ground you mark: for eight seconds bolt after bolt comes down on whoever is under it. |
| 11 | `school_lightning` | The emblem of the school of Lightning: A forked lightning bolt. Simple and bold, to sit on a tab. |
| 12 | (empty) |  |

## spells_utility: Spells: Utility

- **Save as:** `art/spells_utility.png`   **Size:** 1536 x 1024   **Priority:** B
- **Template:** `templates/spells_utility_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Spells: Utility.
The ten spells of the school of Utility, and its emblem. Every icon on this sheet is lit by and coloured with the school's own colour, #ffd98a, on the dark neutral ground of the style lock: one glowing magical effect in each cell, no hands, no figures, no frame or border round it (the game puts each in a round socket).

LAYOUT: Canvas 1536 x 1024 pixels. An invisible grid of 4 columns by 3 rows of equal cells (384 x 341 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. Wisp Light. A spirit-light that follows you for ninety seconds and lights the dark.
2. Mend. A circle of light closes your wounds, restoring 35 life.
3. Fleetfoot. The wind at your back: for twelve seconds you walk and run a third faster.
4. Turn the Dead. Light breaks from your hand. The risen dead within nine paces are driven back, burning, and stand helpless a moment; anything else is dazed.
5. Renew. Your wounds knit as you fight: sixty life, a little at a time, over ten seconds.
6. Life Drain. Hold: a red thread fastens on the nearest foe before you and pulls its stolen life into yours.
7. Aegis. A shell of light that takes the next sixty points of harm for you, for twenty seconds or until it breaks.
8. Sanctuary. Hallows the ground where you stand for ten seconds. Inside it you mend and your mana comes back half again as fast; what means you harm is slowed and seared by it.
9. Empower. Your next three spells bite two-fifths harder. Unspent, it fades in twenty seconds.
10. Stillness. The world slows to a crawl round you for four seconds, your company with it. You do not, and nor does what you cast.
11. The emblem of the school of Utility: A radiant sun disc with short rays. Simple and bold, to sit on a tab.
12. Leave this cell empty.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `wisp` | Wisp Light. A spirit-light that follows you for ninety seconds and lights the dark. |
| 2 | `mend` | Mend. A circle of light closes your wounds, restoring 35 life. |
| 3 | `fleet` | Fleetfoot. The wind at your back: for twelve seconds you walk and run a third faster. |
| 4 | `turn` | Turn the Dead. Light breaks from your hand. The risen dead within nine paces are driven back, burning, and stand helpless a moment; anything else is dazed. |
| 5 | `renew` | Renew. Your wounds knit as you fight: sixty life, a little at a time, over ten seconds. |
| 6 | `drain` | Life Drain. Hold: a red thread fastens on the nearest foe before you and pulls its stolen life into yours. |
| 7 | `aegis` | Aegis. A shell of light that takes the next sixty points of harm for you, for twenty seconds or until it breaks. |
| 8 | `sanctuary` | Sanctuary. Hallows the ground where you stand for ten seconds. Inside it you mend and your mana comes back half again as fast; what means you harm is slowed and seared by it. |
| 9 | `empower` | Empower. Your next three spells bite two-fifths harder. Unspent, it fades in twenty seconds. |
| 10 | `stillness` | Stillness. The world slows to a crawl round you for four seconds, your company with it. You do not, and nor does what you cast. |
| 11 | `school_utility` | The emblem of the school of Utility: A radiant sun disc with short rays. Simple and bold, to sit on a tab. |
| 12 | (empty) |  |

## sockets: Sockets and the medal

- **Save as:** `art/sockets.png`   **Size:** 1024 x 1024   **Priority:** B
- **Template:** `templates/sockets_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Sockets and the medal.
Four round or square settings that things sit in, each filling its cell to the guide. Their centres are empty: the game draws what goes in them.

LAYOUT: Canvas 1024 x 1024 pixels. An invisible grid of 2 columns by 2 rows of equal cells (512 x 512 each), read left to right, top to bottom. One picture in each cell. Each piece fills its cell almost to the edges (to the dashed guide in the template), perfectly centred. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. A round socket a spell's icon sits in: a thin dark iron ring with a narrow bronze-gold inner bead, the centre a dark recessed well. Plainer and thinner-rimmed than the buttons.
2. The same socket, chosen: identical shape, its rim glowing pale gold-white.
3. A square cell of the paper doll that a piece of gear sits in: a recessed dark square with a thin bronze bevel and tiny corner rivets, the centre empty. Square, filling the guide square.
4. The round medal that carries the player's level number: a thick bronze-gold ring with a plain channel round it (the game fills the channel to show progress) and a dark domed centre for the number. No number, no emblem.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `slot_spell` | A round socket a spell's icon sits in: a thin dark iron ring with a narrow bronze-gold inner bead, the centre a dark recessed well. Plainer and thinner-rimmed than the buttons. |
| 2 | `slot_spell_on` | The same socket, chosen: identical shape, its rim glowing pale gold-white. |
| 3 | `slot_item` | A square cell of the paper doll that a piece of gear sits in: a recessed dark square with a thin bronze bevel and tiny corner rivets, the centre empty. Square, filling the guide square. |
| 4 | `medallion` | The round medal that carries the player's level number: a thick bronze-gold ring with a plain channel round it (the game fills the channel to show progress) and a dark domed centre for the number. No number, no emblem. |

## rings: The map's frame and the stick

- **Save as:** `art/rings.png`   **Size:** 1024 x 1024   **Priority:** B
- **Template:** `templates/rings_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: The map's frame and the stick.
The frame of the square map in the corner of the screen, and the round pieces of the left thumb's stick. Each fills its cell to the guide.

LAYOUT: Canvas 1024 x 1024 pixels. An invisible grid of 2 columns by 2 rows of equal cells (512 x 512 each), read left to right, top to bottom. One picture in each cell. Each piece fills its cell almost to the edges (to the dashed guide in the template), perfectly centred. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. The frame of the square corner map: a square frame only, seen straight on, its whole centre empty and transparent (the map shows through). Blackened iron with a bronze-gold inner bead, and a small boss with a garnet stud at each of its four corners. The frame is thin, the same width on all four sides: its outer edge is at the outer guide square and its inner edge at the inner guide square. No compass letters, no pointer.
2. The base the thumbstick moves in: a wide, shallow, mostly see-through dark dish with a thin bronze rim and four faint tick marks at the compass points. Understated: it sits over the game's picture.
3. The thumbstick's knob: a domed disc of pale polished bone with a bronze collar, lit from the top left.
4. Leave this cell empty.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `frame_map` | The frame of the square corner map: a square frame only, seen straight on, its whole centre empty and transparent (the map shows through). Blackened iron with a bronze-gold inner bead, and a small boss with a garnet stud at each of its four corners. The frame is thin, the same width on all four sides: its outer edge is at the outer guide square and its inner edge at the inner guide square. No compass letters, no pointer. |
| 2 | `stick_base` | The base the thumbstick moves in: a wide, shallow, mostly see-through dark dish with a thin bronze rim and four faint tick marks at the compass points. Understated: it sits over the game's picture. |
| 3 | `stick_nub` | The thumbstick's knob: a domed disc of pale polished bone with a bronze collar, lit from the top left. |
| 4 | (empty) |  |

## plates: Buttons, tabs and the rule

- **Save as:** `art/plates.png`   **Size:** 1536 x 1024   **Priority:** B
- **Template:** `templates/plates_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Buttons, tabs and the rule.
The flat rectangular pieces. Each is drawn straight on, filling its box. The game cuts each plate in nine and stretches it to any width, so the ends carry the ornament and the long middle is plain and even. No words on any of them.

LAYOUT: Canvas 1536 x 1024 pixels. The pieces are stacked on the sheet in the places the template shows, each filling its box, with clear empty space between them. Do not draw the boxes or any labels.

THE PIECES, top to bottom, left to right:
1. (696 x 232 px, at 48, 48) A wide button plate, at rest: dark iron with a bronze-gold border, a small ornament at each end, plain dark middle.
2. (696 x 232 px, at 792, 48) The same plate, pressed or under the pointer: same shape, border bright gold, middle faintly lit.
3. (696 x 232 px, at 48, 344) A tab, not chosen: like the button plate but flatter and dimmer, its top corners rounded.
4. (696 x 232 px, at 792, 344) The same tab, chosen: brighter border, warm lit middle, a thin gold line along its bottom edge.
5. (1440 x 120 px, at 48, 664) A dividing rule that sits under a window's title: a thin gold line fading to nothing at both ends, with one small diamond-shaped garnet at its middle.
```

## bars: The bars

- **Save as:** `art/bars.png`   **Size:** 1536 x 1024   **Priority:** B
- **Template:** `templates/bars_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: The bars.
The player's life, mana and breath, and a foe's life. First the trough they sit in, then four fills. Each fill is a long strip of one glowing substance, even from end to end (the game crops it to show how much is left), lit along its top edge. No end caps on the fills, no numbers.

LAYOUT: Canvas 1536 x 1024 pixels. The pieces are stacked on the sheet in the places the template shows, each filling its box, with clear empty space between them. Do not draw the boxes or any labels.

THE PIECES, top to bottom, left to right:
1. (1440 x 216 px, at 48, 40) The trough: a long dark iron channel with a bronze-gold border and a small ornate cap at each end, its middle plain and even (it is stretched). Empty inside.
2. (1440 x 136 px, at 48, 296) Life: deep blood red, glassy, a brighter band along the top.
3. (1440 x 136 px, at 48, 472) Mana: luminous sapphire blue, like lit water.
4. (1440 x 136 px, at 48, 648) Breath: pale straw gold.
5. (1440 x 136 px, at 48, 824) A foe's life: dark crimson with an ember glow, harsher than the player's red.
```

## paper: Parchment

- **Save as:** `art/paper.png`   **Size:** 1024 x 1024   **Priority:** C
- **Template:** `templates/paper_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Parchment.
A sheet of old parchment for letters and pages the player reads: one square sheet filling the picture, seen straight on, warm cream-tan, darker and a little worn toward its edges, slightly ragged outline, even and blank across the middle. Cut in nine like the window frame: keep any tears, stains or curled corners inside the corner squares, and keep the sides and the middle plain.

LAYOUT: Canvas 1024 x 1024 pixels. One frame fills the whole canvas, right to its edges, seen straight on, with four-way symmetry. All ornament is inside the four corner squares (each 192 x 192 pixels); between the corners each side is a plain straight band that looks the same all along its length; the centre is plain and even.
```

## icons_slots: Icons: empty gear slots, and two marks

- **Save as:** `art/icons_slots.png`   **Size:** 1024 x 1024   **Priority:** C
- **Template:** `templates/icons_slots_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Icons: empty gear slots, and two marks.
Ten faint silhouettes that show what goes in an empty gear slot, and two small marks for the spellbook. The silhouettes are dim, single-colour engravings (dull bronze, low contrast), not full paintings: they must not look like an item is there. Leave the last four cells empty.

LAYOUT: Canvas 1024 x 1024 pixels. An invisible grid of 4 columns by 4 rows of equal cells (256 x 256 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. A wizard's pointed hat, as a faint engraved silhouette. An empty head slot.
2. A pair of shoulder guards on a short mantle, as a faint engraved silhouette.
3. A pendant on a chain, as a faint engraved silhouette.
4. A long tunic, sleeveless, as a faint engraved silhouette.
5. A pair of trousers, as a faint engraved silhouette.
6. A pair of boots, as a faint engraved silhouette.
7. A plain finger ring with one small stone, as a faint engraved silhouette.
8. A tall staff standing upright, as a faint engraved silhouette. Fill the cell's height.
9. A kite shield, blank, as a faint engraved silhouette.
10. A small plain human skull in profile, as a faint engraved silhouette. A spell focus the wizard carries.
11. A small faceted diamond-shaped crystal, point up. Marks a branch of a spell.
12. A five-pointed star medal with a small gem at its centre. Marks a school's mastery.
13. Leave this cell empty.
14. Leave this cell empty.
15. Leave this cell empty.
16. Leave this cell empty.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `slot_head` | A wizard's pointed hat, as a faint engraved silhouette. An empty head slot. |
| 2 | `slot_shoulders` | A pair of shoulder guards on a short mantle, as a faint engraved silhouette. |
| 3 | `slot_neck` | A pendant on a chain, as a faint engraved silhouette. |
| 4 | `slot_chest` | A long tunic, sleeveless, as a faint engraved silhouette. |
| 5 | `slot_legs` | A pair of trousers, as a faint engraved silhouette. |
| 6 | `slot_feet` | A pair of boots, as a faint engraved silhouette. |
| 7 | `slot_ring` | A plain finger ring with one small stone, as a faint engraved silhouette. |
| 8 | `slot_main` | A tall staff standing upright, as a faint engraved silhouette. Fill the cell's height. |
| 9 | `slot_off` | A kite shield, blank, as a faint engraved silhouette. |
| 10 | `slot_skull` | A small plain human skull in profile, as a faint engraved silhouette. A spell focus the wizard carries. |
| 11 | `mark_branch` | A small faceted diamond-shaped crystal, point up. Marks a branch of a spell. |
| 12 | `mark_mastery` | A five-pointed star medal with a small gem at its centre. Marks a school's mastery. |
| 13 | (empty) |  |
| 14 | (empty) |  |
| 15 | (empty) |  |
| 16 | (empty) |  |

## icons_goods: Icons: goods, materials and charms

- **Save as:** `art/icons_goods.png`   **Size:** 1024 x 1024   **Priority:** C
- **Template:** `templates/icons_goods_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Icons: goods, materials and charms.
Sixteen small things bought, gathered and carried, painted in full colour as items: one object each, no frame, no background.

LAYOUT: Canvas 1024 x 1024 pixels. An invisible grid of 4 columns by 4 rows of equal cells (256 x 256 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. A simple wooden bed with a red blanket and a pale pillow. A night at the inn.
2. A wooden tankard banded with iron, foam on top.
3. A round bread roll with a scored top.
4. A crusty loaf of bread on a board.
5. A roll of linen bandage with a sprig of green herbs.
6. A lit tallow candle in a small holder.
7. A small stoppered flask of lamp oil, amber through green glass.
8. A tall pale grave candle with wax runs, a soft pale flame.
9. A few old bones crossed in a small pile. A crafting material.
10. A stack of rough iron ingots with two nails. A crafting material.
11. Folded bolts of pale spider silk. A crafting material.
12. Three blocks of yellow beeswax. A crafting material.
13. A glowing orange ember crystal, hot at its heart. A crafting material.
14. A tiny silver bell with a swift's wing cast on its shoulder, hung on a violet thread. A charm.
15. A small cloven hoof shod in iron, hung on a leather thong. A charm.
16. A shard of pale blue crystal bound in silver wire, faintly glowing. A charm.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `bed` | A simple wooden bed with a red blanket and a pale pillow. A night at the inn. |
| 2 | `ale` | A wooden tankard banded with iron, foam on top. |
| 3 | `roll` | A round bread roll with a scored top. |
| 4 | `loaf` | A crusty loaf of bread on a board. |
| 5 | `dressing` | A roll of linen bandage with a sprig of green herbs. |
| 6 | `candle` | A lit tallow candle in a small holder. |
| 7 | `oil` | A small stoppered flask of lamp oil, amber through green glass. |
| 8 | `grave_candle` | A tall pale grave candle with wax runs, a soft pale flame. |
| 9 | `bone` | A few old bones crossed in a small pile. A crafting material. |
| 10 | `iron` | A stack of rough iron ingots with two nails. A crafting material. |
| 11 | `silk` | Folded bolts of pale spider silk. A crafting material. |
| 12 | `wax` | Three blocks of yellow beeswax. A crafting material. |
| 13 | `ember` | A glowing orange ember crystal, hot at its heart. A crafting material. |
| 14 | `wingbell` | A tiny silver bell with a swift's wing cast on its shoulder, hung on a violet thread. A charm. |
| 15 | `goatfoot` | A small cloven hoof shod in iron, hung on a leather thong. A charm. |
| 16 | `glimmerstone` | A shard of pale blue crystal bound in silver wire, faintly glowing. A charm. |

## gems: Icons: the gems

- **Save as:** `art/gems.png`   **Size:** 1536 x 1024   **Priority:** C
- **Template:** `templates/gems_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Icons: the gems.
The eighteen gems that are set into staffs, skulls and shields: six kinds across, three grades down. Each column is one kind, in its own colour; each row is one grade. Top row, rough: an uncut, lumpy, cloudy stone. Middle row, cut: a clean six-sided faceted stone. Bottom row, flawless: a brilliant many-faceted stone with a bright inner light and a small glint. The three in a column are plainly the same stone getting finer; the six in a row are plainly the same cut in different colours. Loose stones only: no settings, no rings, no frames.

LAYOUT: Canvas 1536 x 1024 pixels. An invisible grid of 6 columns by 3 rows of equal cells (256 x 341 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. A ruby, deep red: uncut and cloudy.
2. A topaz, warm amber gold: uncut and cloudy.
3. A emerald, green: uncut and cloudy.
4. A sapphire, blue: uncut and cloudy.
5. A amethyst, violet: uncut and cloudy.
6. A diamond, clear, pale ice white: uncut and cloudy.
7. A ruby, deep red: cleanly faceted.
8. A topaz, warm amber gold: cleanly faceted.
9. A emerald, green: cleanly faceted.
10. A sapphire, blue: cleanly faceted.
11. A amethyst, violet: cleanly faceted.
12. A diamond, clear, pale ice white: cleanly faceted.
13. A ruby, deep red: brilliant, many-faceted, lit from within.
14. A topaz, warm amber gold: brilliant, many-faceted, lit from within.
15. A emerald, green: brilliant, many-faceted, lit from within.
16. A sapphire, blue: brilliant, many-faceted, lit from within.
17. A amethyst, violet: brilliant, many-faceted, lit from within.
18. A diamond, clear, pale ice white: brilliant, many-faceted, lit from within.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `gem_ruby_0` | A ruby, deep red: uncut and cloudy. |
| 2 | `gem_topaz_0` | A topaz, warm amber gold: uncut and cloudy. |
| 3 | `gem_emerald_0` | A emerald, green: uncut and cloudy. |
| 4 | `gem_sapphire_0` | A sapphire, blue: uncut and cloudy. |
| 5 | `gem_amethyst_0` | A amethyst, violet: uncut and cloudy. |
| 6 | `gem_diamond_0` | A diamond, clear, pale ice white: uncut and cloudy. |
| 7 | `gem_ruby_1` | A ruby, deep red: cleanly faceted. |
| 8 | `gem_topaz_1` | A topaz, warm amber gold: cleanly faceted. |
| 9 | `gem_emerald_1` | A emerald, green: cleanly faceted. |
| 10 | `gem_sapphire_1` | A sapphire, blue: cleanly faceted. |
| 11 | `gem_amethyst_1` | A amethyst, violet: cleanly faceted. |
| 12 | `gem_diamond_1` | A diamond, clear, pale ice white: cleanly faceted. |
| 13 | `gem_ruby_2` | A ruby, deep red: brilliant, many-faceted, lit from within. |
| 14 | `gem_topaz_2` | A topaz, warm amber gold: brilliant, many-faceted, lit from within. |
| 15 | `gem_emerald_2` | A emerald, green: brilliant, many-faceted, lit from within. |
| 16 | `gem_sapphire_2` | A sapphire, blue: brilliant, many-faceted, lit from within. |
| 17 | `gem_amethyst_2` | A amethyst, violet: brilliant, many-faceted, lit from within. |
| 18 | `gem_diamond_2` | A diamond, clear, pale ice white: brilliant, many-faceted, lit from within. |

## icons_marks: Icons: quest marks and party roles

- **Save as:** `art/icons_marks.png`   **Size:** 1536 x 1024   **Priority:** C
- **Template:** `templates/icons_marks_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: Icons: quest marks and party roles.
Six marks. The top three float over the heads of people in the world who have work for you, so they must read from far off: big, simple, glowing, with a dark outline. They are punctuation marks, the one place in the whole set where a written mark is wanted: paint only the mark asked for, nothing else written. The bottom three say what a hired companion is for, beside their name in a list.

LAYOUT: Canvas 1536 x 1024 pixels. An invisible grid of 3 columns by 2 rows of equal cells (512 x 512 each), read left to right, top to bottom. One picture in each cell. Each picture is centred in its cell and fills about four fifths of it, with clear empty space between it and its neighbours: nothing touches or crosses a cell's edge. All the pictures are the same size as each other and sit on one baseline grid, like stickers on a sheet. Do not draw the grid, the cell numbers or any labels.

THE PICTURES, by cell:
1. A bold exclamation mark of bright gold with a dark brown outline. Someone has work to offer.
2. A bold question mark of bright gold with a dark brown outline. A task is ready to hand in.
3. The same bold question mark in dull grey stone with a dark outline. A task taken and not yet done.
4. A tall tower shield, plain steel, front on, with a raised rim and no device. The one who takes the blows.
5. An open palm with a sprig of green healing herb glowing softly above it. The one who heals.
6. A single dagger pointing up and to the right, a bright spark at its tip. The ones who do the damage.
```

| Cell | Name in the game | What it is |
| --- | --- | --- |
| 1 | `quest_offer` | A bold exclamation mark of bright gold with a dark brown outline. Someone has work to offer. |
| 2 | `quest_ready` | A bold question mark of bright gold with a dark brown outline. A task is ready to hand in. |
| 3 | `quest_busy` | The same bold question mark in dull grey stone with a dark outline. A task taken and not yet done. |
| 4 | `role_tank` | A tall tower shield, plain steel, front on, with a raised rim and no device. The one who takes the blows. |
| 5 | `role_heal` | An open palm with a sprig of green healing herb glowing softly above it. The one who heals. |
| 6 | `role_dps` | A single dagger pointing up and to the right, a bright spark at its tip. The ones who do the damage. |

## app_icon: The app's icon

- **Save as:** `art/app_icon.png`   **Size:** 1024 x 1024   **Priority:** C
- **Template:** `templates/app_icon_template.png`

**Prompt for the image tool** (attach the template and `reference/style_anchors.png`; send all of it):

```
BELLMOURN INTERFACE STYLE LOCK, version 1. The same for every picture in this set.

MEDIUM: hand-painted dark-fantasy game interface art, in the manner of a gothic action role-playing game of the late 1990s
and 2000s. Painterly and a little gritty, with visible brushwork and small nicks and wear. Not vector art, not flat design,
not glossy mobile-game plastic, not pixel art, not a 3D render, not a photograph.

MATERIALS, and only these: blackened wrought iron; aged bronze-gold worked in fine filigree with a beaded inner edge;
small round cabochon garnets, deep red, used sparingly as studs; old bone and ivory; dark oiled leather; cream parchment.

COLOURS (hex): night ground #0b0907; iron #14100b, where lit #3a3024; bronze-gold #c9a35c, its highlights #f1d68a, its
shadows #8c7344; bone #e9dfc9; garnet #8e1a12, where lit #d23a22; parchment #ecdfc2. Magic takes its school's colour and
nothing else: fire #ff9a3c, ice #8fd4ff, earth #d8b184, arcane #d27bff, lightning #a79bff, light #ffd98a. Keep everything
else low in saturation: the gold, the garnets and the magic are the only strong colour.

LIGHT: one soft warm light from the upper left, a faint cool rim on the lower right. Shading stays on the object: no
long cast shadows, no glow or haze spreading away from it.

FORM: bold silhouettes that read when the picture is shrunk to the size of a fingernail (32 pixels). A dark outline two
or three pixels wide round every object. Moderate detail: a few strong shapes, not many small ones. Frames, buttons,
plates and bars are seen exactly straight on, with no tilt and no perspective. Objects on icons are seen like items in a
game's inventory: slightly from above, three-quarter view, each on its own with nothing else in the picture.

BACKGROUND: completely transparent, a true alpha channel, with nothing at all behind the art: no ground, no shadow
blob, no vignette, no frame, and never a grey-and-white checkerboard painted in to look like transparency. Only if true
transparency is impossible, use one flat pure green, #00ff00, everywhere behind the art instead, with no gradient.

NEVER: letters, numbers, words, runes or marks that read as letters, monograms, signatures, watermarks, logos. Never the
letter V or the letter T, or a shape that reads as one, on anything. No upright crosses, pentagrams, horned or demonic
skulls used as a badge, winged or haloed figures, or any heraldry or emblem of a real or invented faith or house. No extra objects that
weren't asked for. Nothing cut off by the edge of its space.

ONE SET: the same iron, the same gold, the same garnets, the same brush and the same outline weight as the attached
reference picture of the game's existing button and skull. If in doubt, plainer.

THIS SHEET: The app's icon.
The icon on a phone's home screen. A full square picture with no transparency and no rounded corners (the phone rounds them): a great bronze church bell hanging in darkness, lit from below by a faint ember glow, on a near-black background with a subtle vignette. Keep the bell inside the middle 70% of the square (phones crop the edges). No letters, no title, no frame.

LAYOUT: Canvas 1024 x 1024 pixels. One picture fills the whole square, with no transparency.
```
